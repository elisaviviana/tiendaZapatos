package com.tiendazapatos.zapatosspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZapatosspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
