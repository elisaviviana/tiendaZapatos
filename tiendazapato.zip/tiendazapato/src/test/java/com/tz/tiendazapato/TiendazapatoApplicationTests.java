package com.tz.tiendazapato;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendazapatoApplicationTests {

	@Test
	void contextLoads() {
	}

}
