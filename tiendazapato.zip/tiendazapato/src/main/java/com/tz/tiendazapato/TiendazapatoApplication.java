package com.tz.tiendazapato;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiendazapatoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiendazapatoApplication.class, args);
	}

}
