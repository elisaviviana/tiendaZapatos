package com.tiendazapatos.zapatosspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZapatosspringApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZapatosspringApplication.class, args);
	}

}
